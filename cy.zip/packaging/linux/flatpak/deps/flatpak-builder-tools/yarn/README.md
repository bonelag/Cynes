> [!WARNING]
> This is deprecated use [flatpak-node-generator](../node/README.md).
