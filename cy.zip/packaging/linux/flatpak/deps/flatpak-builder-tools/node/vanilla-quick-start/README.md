# vanilla-quick-start

Showcases building a Flatpak of the Electron 18 version of
[electron-quick-start](https://github.com/electron/electron-quick-start).

To create generated-sources.json run:

```sh
flatpak-node-generator npm /path/to/electron-quick-start/package-lock.json
```

(Make sure your local clone of electron-quick-start is at the same commit as used in the manifest
file.)
