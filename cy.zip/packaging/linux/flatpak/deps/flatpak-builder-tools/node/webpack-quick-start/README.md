# webpack-quick-start

Showcases building a Flatpak of [electron-webpack-quick-start](
https://github.com/electron-userland/electron-webpack-quick-start/).

To create generated-sources.json run:

```sh
flatpak-node-generator yarn /path/to/electron-webpack-quick-start/yarn.lock
```

(Make sure your local clone of electron-webpack-quick-start is at the same commit as used in the
manifest file.)
