This submodule contains the manifests and several patches for SDL1 and its compatibility layer.

If using the compatibility layer, please add the SDL2 submodule as a dependency as well to benefit from the latest bug fixes.
